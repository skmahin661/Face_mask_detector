import streamlit as st
import numpy as np
import cv2
from tensorflow.keras.models import load_model
from PIL import Image

st.set_page_config(page_title="Face Mask Detector", layout="centered")

# Load the trained model
model = load_model("mask_detector_model.h5")

IMG_SIZE = 100

st.title("😷 Real-Time Face Mask Detector")

# Upload image option
uploaded_file = st.file_uploader("Upload an image", type=["jpg", "png", "jpeg"])

if uploaded_file:
    image = Image.open(uploaded_file)
    st.image(image, caption="Uploaded Image", use_column_width=True)

    # Convert to OpenCV format
    image_np = np.array(image)
    image_np = cv2.cvtColor(image_np, cv2.COLOR_RGB2BGR)

    face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + "haarcascade_frontalface_default.xml")
    gray = cv2.cvtColor(image_np, cv2.COLOR_BGR2GRAY)
    faces = face_cascade.detectMultiScale(gray, 1.1, 4)

    for (x, y, w, h) in faces:
        face = image_np[y:y+h, x:x+w]
        face_resized = cv2.resize(face, (IMG_SIZE, IMG_SIZE))
        face_resized = np.expand_dims(face_resized, axis=0)
        face_resized = face_resized / 255.0
        prediction = model.predict(face_resized)[0]

        label = "Mask 😷" if np.argmax(prediction) == 0 else "No Mask ❌"
        color = (0, 255, 0) if label == "Mask 😷" else (0, 0, 255)

        cv2.rectangle(image_np, (x, y), (x+w, y+h), color, 2)
        cv2.putText(image_np, label, (x, y - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.9, color, 2)

    st.image(cv2.cvtColor(image_np, cv2.COLOR_BGR2RGB), caption="Processed Image", use_column_width=True)
